#ifndef DIGIT_H_INCLUDED
#define DIGIT_H_INCLUDED

#include <array>
using namespace std;
array<int, 15>& MAssive(array<int, 15>&);
void Out(array<int, 15>&);
void Task17(array<int, 15>&);
int Rand();
#endif // DIGIT_H_INCLUDED
