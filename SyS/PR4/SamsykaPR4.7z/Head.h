#ifndef HEAD_H
#define HEAD_H
#include <vector>
std::vector<int> MasIn(std::vector<int>);
int Random();
void Out(vector<int>&)
void LocalMin(std::vector<int>);
#endif // HEAD_H
