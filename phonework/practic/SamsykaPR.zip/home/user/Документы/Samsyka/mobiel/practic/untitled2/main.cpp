/*!
 * \brief Работа с файлами/ Практическая работа №9
 * \details 8.1 1) Здание. Вывести здания которым больше 50 лет
 *          8.1 2) Файл с числами. Найти не делящиеся на 7 но делящиеся на 3
 *          8.2 1)
 * / Вариант 17
 * \author  Самсыка Р. М. / И-32 группа
 * \version 0.1
 * \date 27.03.2025
 * \copyright GNU Public License.
 */
#include <QFile>
#include <QTextStream>
int main()
{
    QString filename1 = "./inputs/input811";
    QString filename2 = "./inputs/input812";
    QString filename3 = "./inputs/input821";
    QString filenameOut = "./outputs/output";

    QFile file1(filename1);
    QFile file2(filename2);
    QFile file3(filename3);
    QFile fileOut(filenameOut);

    //задание 8.1 1 - Здания
    if(file1.open(QIODevice::ReadOnly)){
        QString homes;
        QString line;
        QTextStream in(&file1);
        while(!in.atEnd()){
            line = in.readLine();
            if(line.split("; ").at(4).split(' ').at(0).toInt() >= 50) homes += line + "\n";
        }
        if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream out(&fileOut);
            out << "Здания старше 50 лет"<< Qt::endl<<homes;
        }
    }
    file1.close();

    //задание 8.1 2 - Числа
    if(file2.open(QIODevice::ReadOnly)){
        QString numbers;
        QString number;
        QTextStream in(&file2);
        while(!in.atEnd()){
            number = in.readLine();
            if(line.split("; ").at(4).split(' ').at(0).toInt() >= 50) homes += line + "\n";
        }
        if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream out(&fileOut);
            out << "Здания старше 50 лет"<< Qt::endl<<homes;
        }
    }
    file2.close();

    //задание 8.2 1 - Здания
    if(file1.open(QIODevice::ReadOnly)){
        QString homes;
        QString line;
        QTextStream in(&file1);
        while(!in.atEnd()){
            line = in.readLine();
            if(line.split("; ").at(4).split(' ').at(0).toInt() >= 50) homes += line + "\n";
        }
        if(fileOut.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream out(&fileOut);
            out << "Здания старше 50 лет"<< Qt::endl<<homes;
        }
    }
    file3.close();
    fileOut.close();
    return 0;
}


